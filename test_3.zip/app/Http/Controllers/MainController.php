<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Dompdf\Dompdf;

//Model
use App\Product;
use App\Discount;
use App\Order;

class MainController extends Controller
{
    public function ShowFirstPage()
    {
        return view('first-page');
    }

    public function ShowSecondPage()
    {
        return view('second-page');
    }

    public function download()
    { 
        $dompdf = new Dompdf();
        $dompdf->set_option('isHtml5ParserEnabled', true);
        $dompdf->load_html(view('first-page')->render());
        $dompdf->render();      
        return $dompdf->stream('hello.pdf');
    }

    public function ShowProductPage()
    {
        $product = Product::all();
        $data = [];
        $data['lst_product'] = $product;
        return view('product')->with($data);
    }

    public function CheckDiscountCode(Request $request)
    {
        $data = [];
        if(empty($request->all())){
            $data['status'] = false;
            $data['message'] = 'Whoops, parameter is needed';
            return \response()->json($data);
        }
        else
        {
            $discount = Discount::whereRaw('discount_code LIKE CONCAT("%", "'.$request["discount_code"].'", "%")')->first();
            if(empty($discount))
            {
                $data['status'] = false;
                $data['message'] = 'Whoops code not found';
            }
            else
            {
                $data['status'] = true;
                $data['discount'] = $discount;
            }
            return \response()->json($data);
        }
    }

    public function SubmitOrder(Request $request) 
    {
        $data = [];
        if(empty($request->all())){
            $data['status'] = false;
            $data['message'] = 'Whoops, parameter is needed';
            return \response()->json($data);
        }
        else
        {
            $order = $request['order'];

            foreach($order as $key) {
                $order_model              = new Order();
                $order_model->product_id  = $key['product_id'];
                $order_model->quantity    = $key['quantity'];
                $order_model->price       = $key['price'];
                $order_model->discount_id = $request['discount_id'];

                if(!$order_model->save()) {
                    $data['status'] = false;
                    $data['message'] = 'Whoops something went wrong, try again later..';
                    break;
                }
            }

            $data['status'] = true;
            $data['message'] = 'Successfully input order';

            return \response()->json($data);
        }
    }
}
